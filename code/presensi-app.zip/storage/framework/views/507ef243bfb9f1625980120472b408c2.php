<div>
    <!--[if BLOCK]><![endif]--><?php if($isHome): ?>
        <div class="section-header">
            <h1>Absence Menu</h1>
        </div>

        <div class="section-body">
            <h2 class="section-title">Absence List</h2>
            <p class="section-lead">In this section you can manage system Absence data such as adding, changing and deleting.</p>
            <div class="card">
                <div class="card-body">
                    <!--[if BLOCK]><![endif]--><?php if($alert): ?>
                        <div class="alert alert-primary alert-has-icon">
                            <div class="alert-icon"><i class="fas fa-file-signature"></i></div>
                            <div class="alert-body">
                                <div class="alert-title">No Today Record</div>
                                You haven't checked in today. <br><br>
                                <a wire:click.prevent="in()" href="#" class="btn btn-outline-light">Check In Now!</a>
                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible show fade">
                            <div class="alert-body">
                            <button class="close" data-dismiss="alert">
                                <span>×</span>
                            </button>
                            <?php echo e(session('success')); ?>

                            </div>
                        </div>
                        <br>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <p><strong>Absences History</strong></p>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Day</th>
                            <th scope="col">Date</th>
                            <th scope="col">Checked In</th>
                            <th scope="col">Checked Out</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $absens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($index +1); ?></th>
                                    <td><?php echo e($a->day); ?></td>
                                    <td><?php echo e($a->date); ?></td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($a->absenHasPresensis[0]->checkin == null): ?>
                                            <i class="fas fa-users"></i>
                                        <?php else: ?>
                                        <i class="fas fa-check-circle"></i>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($a->absenHasPresensis[0]->checkout == null): ?>
                                            <a wire:click.prevent="out(<?php echo e($a->id); ?>)" href="#" class="btn btn-icon btn-outline-danger"><i class="fas fa-sign-out-alt"></i></a>
                                        <?php else: ?>
                                        <i class="fas fa-check-circle"></i>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td>
                                        <div class="buttons">
                                            <a wire:click.prevent="show(<?php echo e($a->id); ?>)" href="#" class="btn btn-icon btn-info"><i class="fas fa-info-circle"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if(count($absens) === 0): ?>
                            <tr>
                                <td colspan="6" class="text-center">No Data Found</td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                    <?php echo e($absens->links()); ?>

                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($isIn): ?>
        <div class="section-header">
            <h1>Check In Station</h1>
        </div>

        <div class="section-body">
            <h2 class="section-title">Check In Station</h2>
            <p class="section-lead">In this section you can check in.</p>
            <div class="card">
                <div class="card-body">
                    <p><strong>Check In Form!</strong></p>
                    <form wire:submit.prevent="storeIn">
                        <div class="form-group">
                            <label>Status</label>
                            <select class="form-control" name="status" id="status" wire:model="status">
                                <option>Choose Status</option>
                                <option value="1">Hadir</option>
                                <option value="2">Izin</option>
                                <option value="3">Sakit</option>
                                <option value="4">Alpha</option>
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="form-group">
                            <label for="name">Today Plan</label>
                            <input type="text" class="form-control" id="name" wire:model="plan">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['plan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <a href="#" wire:click="home()" class="btn btn-primary">Back</a>
                        <button class="submit btn btn-success">Save</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($isOut): ?>
        <div class="section-header">
            <h1>Check Out Station</h1>
        </div>

        <div class="section-body">
            <h2 class="section-title">Check Out Station</h2>
            <p class="section-lead">In this section you can check out.</p>
            <div class="card">
                <div class="card-body">
                    <p><strong>Check Out Form!</strong></p>
                    <form wire:submit.prevent="storeOut">
                        <div class="form-group">
                            <label for="name">Today Result</label>
                            <input type="text" class="form-control" id="name" wire:model="result">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <a href="#" wire:click="home()" class="btn btn-primary">Back</a>
                        <button class="submit btn btn-success">Save</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($isDetail): ?>
        <div class="section-header">
            <h1>Absence Information</h1>
        </div>

        <div class="section-body">
            <h2 class="section-title">Detail Information</h2>
            <p class="section-lead">In this section you can show detail of your absence information.</p>
            <div class="card">
                <div class="card-body">
                    <p><strong>General Information</strong></p>
                    <table class="table table-striped table-borderless">
                        <tr>
                            <th>Day</th>
                            <td><?php echo e($details->day); ?></td>
                        </tr>
                        <tr>
                            <th>Date</th>
                            <td><?php echo e($details->date); ?></td>
                        </tr>
                        <tr>
                            <th>Created At</th>
                            <td><?php echo e($details->created_at); ?></td>
                        </tr>
                        <tr>
                            <th>Updated At</th>
                            <td><?php echo e($details->updated_at); ?></td>
                        </tr>
                    </table>
                    <hr>
                    <div class="row">
                        <div class="col-6">
                            <p><strong>Check In Information</strong></p>
                            <table class="table table-striped table-borderless">
                                <tr>
                                    <th>Check In Time</th>
                                    <td><?php echo e($details->absenHasPresensis[0]->checkin->created_at); ?></td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($details->absenHasPresensis[0]->checkin->status == 1): ?>
                                            <span class="badge badge-success">Hadir</span>
                                        <?php elseif($details->absenHasPresensis[0]->checkin->status == 2): ?>
                                            <span class="badge badge-warning">Izin</span>
                                        <?php elseif($details->absenHasPresensis[0]->checkin->status == 3): ?>
                                            <span class="badge badge-info">Sakit</span>
                                        <?php elseif($details->absenHasPresensis[0]->checkin->status == 4): ?>
                                            <span class="badge badge-danger">Alpha</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                </tr>
                                <tr>
                                    <th>Plan</th>
                                    <td><?php echo e($details->absenHasPresensis[0]->checkin->description); ?></td>
                                </tr>
                                <tr>
                                    <th>Device</th>
                                    <td><?php echo e($details->absenHasPresensis[0]->checkin->device); ?></td>
                                </tr>
                                <tr>
                                    <th>Platform / Version</th>
                                    <td><?php echo e($details->absenHasPresensis[0]->checkin->platform); ?> / <?php echo e($details->absenHasPresensis[0]->checkin->platform_version); ?></td>
                                </tr>
                                <tr>
                                    <th>Browser / Version</th>
                                    <td><?php echo e($details->absenHasPresensis[0]->checkin->browser); ?> / <?php echo e($details->absenHasPresensis[0]->checkin->browser_version); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-6">
                            <p><strong>Check Out Information</strong></p>
                            <!--[if BLOCK]><![endif]--><?php if($details->absenHasPresensis[0]->checkout == null): ?>
                                <div class="alert alert-warning">
                                    <div class="alert-title">Be Careful!</div>
                                    You haven't checked out yet..
                                </div>
                            <?php else: ?>
                                <table class="table table-striped table-borderless">
                                    <tr>
                                        <th>Check Out Time</th>
                                        <td><?php echo e($details->absenHasPresensis[0]->checkout->created_at); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Result</th>
                                        <td><?php echo e($details->absenHasPresensis[0]->checkout->description); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Device</th>
                                        <td><?php echo e($details->absenHasPresensis[0]->checkout->device); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Platform / Version</th>
                                        <td><?php echo e($details->absenHasPresensis[0]->checkout->platform); ?> / <?php echo e($details->absenHasPresensis[0]->checkout->platform_version); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Browser / Version</th>
                                        <td><?php echo e($details->absenHasPresensis[0]->checkout->browser); ?> / <?php echo e($details->absenHasPresensis[0]->checkout->browser_version); ?></td>
                                    </tr>
                                </table>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <a href="#" wire:click="home()" class="btn btn-primary">Back</a>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH E:\Repo\PROJECTS\JOKI\presensi-app\resources\views/livewire/absensi-menu.blade.php ENDPATH**/ ?>