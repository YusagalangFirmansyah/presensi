<div>
    <!--[if BLOCK]><![endif]--><?php if($isHome): ?>
        <div class="section-header">
            <h1>Reporting DayLog</h1>
        </div>

        <div class="section-body">
            <h2 class="section-title">Reporting List</h2>
            <p class="section-lead">In this section you can manage reporting of application by the user.</p>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">

                        </div>
                        <div class="col-4">
                            <input type="text" class="form-control" id="search" placeholder="Search User"
                                wire:model.live.debounce.250ms="search">
                        </div>
                        <div class="col-4 text-right">

                        </div>
                    </div>
                    <br>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name User</th>
                                <th scope="col">Division</th>
                                <th scope="col">Category</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key + 1); ?></th>
                                    <td><?php echo e($value->name); ?></td>
                                    <td><?php echo e($value->division->name ?? ''); ?></td>
                                    <td><?php echo e($value->category->name ?? ''); ?></td>
                                    <td>
                                        <button wire:click.prevent="userDetail(<?php echo e($value->id); ?>)"
                                            class="btn btn-primary">Detail</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($isUserDetail): ?>
        <div class="section-header">
            <h1>Reporting DayLog</h1>
        </div>

        <div class="section-body">
            <h2 class="section-title">Reporting List</h2>
            <p class="section-lead">In this section you can manage reporting of application by the user.</p>
            <div class="card">
                <div class="card-body">
                    <p><strong>User Information</strong></p>
                    <table class="table table-striped table-borderless">
                        <tr>
                            <th>Name</th>
                            <td>:</td>
                            <td><?php echo e($detail->name); ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td>:</td>
                            <td><?php echo e($detail->email); ?></td>
                        </tr>
                        <tr>
                            <th>Division</th>
                            <td>:</td>
                            <td><?php echo e($detail->division->name ?? ''); ?></td>
                        </tr>
                        <tr>
                            <th>Category</th>
                            <td>:</td>
                            <td><?php echo e($detail->category->name ?? ''); ?></td>
                        </tr>
                    </table>
                    <hr>
                    <div class="row">
                        <div class="col-6">
                            <p><strong>Absence Activity</strong></p>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Day</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">In</th>
                                        <th scope="col">Out</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!--[if BLOCK]><![endif]--><?php if(count($absences) === 0): ?>
                                        <tr>
                                            <td colspan="6" class="text-center">No Data Found</td>
                                        </tr>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $absences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($index + 1); ?></th>
                                            <td><?php echo e($a->day); ?></td>
                                            <td><?php echo e($a->date); ?></td>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php if($a->absenHasPresensis[0]->checkin == null): ?>
                                                    <p>-</p>
                                                <?php elseif($a->absenHasPresensis[0]->checkin != null): ?>
                                                    <p><?php echo e($a->absenHasPresensis[0]->checkin->created_at); ?></p>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php if($a->absenHasPresensis[0]->checkout == null): ?>
                                                    <p>-</p>
                                                <?php elseif($a->absenHasPresensis[0]->checkout != null): ?>
                                                    <p><?php echo e($a->absenHasPresensis[0]->checkout->created_at); ?></p>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td>
                                                <a href="#"
                                                    wire:click.prevent="detailAbsence(<?php echo e($a->id); ?>)"
                                                    class="btn btn-info">Detail</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                            </table>
                        </div>
                        <div class="col-6 border-left">
                            <p><strong>Detail Absence Activity</strong></p>
                            <!--[if BLOCK]><![endif]--><?php if($alertAbsence): ?>
                                <div class="alert alert-info alert-has-icon">
                                    <div class="alert-icon"><i class="far fa-lightbulb"></i></div>
                                    <div class="alert-body">
                                        <div class="alert-title">Info</div>
                                        Please select Absence First!
                                    </div>
                                </div>
                            <?php else: ?>
                                <p><strong>General Information</strong></p>
                                <table class="table table-striped table-borderless">
                                    <tr>
                                        <th>Day</th>
                                        <td>:</td>
                                        <td><?php echo e($absen->day); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Date</th>
                                        <td>:</td>
                                        <td><?php echo e($absen->date); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Created At</th>
                                        <td>:</td>
                                        <td><?php echo e($absen->created_at); ?></td>
                                    </tr>
                                </table>
                                <p><strong>Check In Information</strong></p>
                                <table class="table table-striped table-borderless">
                                    <tr>
                                        <th>Check In Time</th>
                                        <td>:</td>
                                        <td><?php echo e($absen->absenHasPresensis[0]->checkin->created_at); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Status</th>
                                        <td>:</td>
                                        <td>
                                            <!--[if BLOCK]><![endif]--><?php if($absen->absenHasPresensis[0]->checkin->status == 1): ?>
                                                <span class="badge badge-success">Hadir</span>
                                            <?php elseif($absen->absenHasPresensis[0]->checkin->status == 2): ?>
                                                <span class="badge badge-warning">Izin</span>
                                            <?php elseif($absen->absenHasPresensis[0]->checkin->status == 3): ?>
                                                <span class="badge badge-info">Sakit</span>
                                            <?php elseif($absen->absenHasPresensis[0]->checkin->status == 4): ?>
                                                <span class="badge badge-danger">Alpha</span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Plan</th>
                                        <td>:</td>
                                        <td><?php echo e($absen->absenHasPresensis[0]->checkin->description); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Device</th>
                                        <td>:</td>
                                        <td><?php echo e($absen->absenHasPresensis[0]->checkin->device); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Platform / Version</th>
                                        <td>:</td>
                                        <td><?php echo e($absen->absenHasPresensis[0]->checkin->platform); ?> /
                                            <?php echo e($absen->absenHasPresensis[0]->checkin->platform_version); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Browser / Version</th>
                                        <td>:</td>
                                        <td><?php echo e($absen->absenHasPresensis[0]->checkin->browser); ?> /
                                            <?php echo e($absen->absenHasPresensis[0]->checkin->browser_version); ?></td>
                                    </tr>
                                </table>
                                <p><strong>Check Out Information</strong></p>
                                <!--[if BLOCK]><![endif]--><?php if($absen->absenHasPresensis[0]->checkout == null): ?>
                                    <div class="alert alert-warning">
                                        <div class="alert-title">Warning</div>
                                        This user not check out yet.
                                    </div>
                                <?php else: ?>
                                    <table class="table table-striped table-borderless">
                                        <tr>
                                            <th>Check Out Time</th>
                                            <td>:</td>
                                            <td><?php echo e($absen->absenHasPresensis[0]->checkout->created_at); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Result</th>
                                            <td>:</td>
                                            <td><?php echo e($absen->absenHasPresensis[0]->checkin->description); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Device</th>
                                            <td>:</td>
                                            <td><?php echo e($absen->absenHasPresensis[0]->checkin->device); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Platform / Version</th>
                                            <td>:</td>
                                            <td><?php echo e($absen->absenHasPresensis[0]->checkin->platform); ?> /
                                                <?php echo e($absen->absenHasPresensis[0]->checkin->platform_version); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Browser / Version</th>
                                            <td>:</td>
                                            <td><?php echo e($absen->absenHasPresensis[0]->checkin->browser); ?> /
                                                <?php echo e($absen->absenHasPresensis[0]->checkin->browser_version); ?></td>
                                        </tr>
                                    </table>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-6">
                            <p><strong>Logbook Activity</strong></p>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Day</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Time</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!--[if BLOCK]><![endif]--><?php if(count($logbooks) === 0): ?>
                                        <tr>
                                            <td colspan="5" class="text-center">No Data Found</td>
                                        </tr>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $logbooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($index + 1); ?></th>
                                            <td><?php echo e($a->day); ?></td>
                                            <td><?php echo e($a->date); ?></td>
                                            <td><?php echo e($a->time); ?></td>
                                            <td>
                                                <a href="#"
                                                    wire:click.prevent="detailLogbook(<?php echo e($a->id); ?>)"
                                                    class="btn btn-info">Detail</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                            </table>
                        </div>
                        <div class="col-6 border-left">
                            <p><strong>Detail Logbook Activity</strong></p>
                            <!--[if BLOCK]><![endif]--><?php if($alertLogbook): ?>
                                <div class="alert alert-info alert-has-icon">
                                    <div class="alert-icon"><i class="far fa-lightbulb"></i></div>
                                    <div class="alert-body">
                                        <div class="alert-title">Info</div>
                                        Please select Logbook First!
                                    </div>
                                </div>
                            <?php else: ?>
                                <table class="table table-striped table-borderless">
                                    <tr>
                                        <th>Day</th>
                                        <td>:</td>
                                        <td><?php echo e($logbook->day); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Date</th>
                                        <td>:</td>
                                        <td><?php echo e($logbook->date); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Time</th>
                                        <td>:</td>
                                        <td><?php echo e($logbook->time); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Feeling</th>
                                        <td>:</td>
                                        <td>
                                            <!--[if BLOCK]><![endif]--><?php if($logbook->feeling == 1): ?>
                                                <span class="badge badge-danger">Menyebalkan</span>
                                            <?php elseif($logbook->feeling == 2): ?>
                                                <span class="badge badge-warning">Membosankan</span>
                                            <?php elseif($logbook->feeling == 3): ?>
                                                <span class="badge badge-info">Biasa aja</span>
                                            <?php elseif($logbook->feeling == 4): ?>
                                                <span class="badge badge-primary">Menarik</span>
                                            <?php elseif($logbook->feeling == 5): ?>
                                                <span class="badge badge-success">Seru</span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Activity</th>
                                        <td>:</td>
                                        <td><?php echo e($logbook->activity); ?></td>
                                    </tr>
                                </table>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <p><strong>Leave/Permission Activity</strong></p>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Type</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Reason</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!--[if BLOCK]><![endif]--><?php if(count($pengajuans) === 0): ?>
                                        <tr><td colspan="6" class="text-center">No data.</td></tr>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $pengajuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td class="text-capitalize"><?php echo e($p->type); ?></td>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php if($p->type === 'cuti'): ?>
                                                    <?php echo e($p->start_date); ?> to <?php echo e($p->end_date); ?>

                                                <?php else: ?>
                                                    <?php echo e($p->date); ?>

                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td><?php echo e(Str::limit($p->reason, 30)); ?></td>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php if($p->status === 'pending'): ?>
                                                    <span class="badge badge-warning">Pending</span>
                                                <?php elseif($p->status === 'approved'): ?>
                                                    <span class="badge badge-success">Approved</span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger">Rejected</span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td>
                                                <button wire:click.prevent="detailPengajuan(<?php echo e($p->id); ?>)" class="btn btn-info btn-sm">Detail</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                            </table>
                        </div>
                        <div class="col-6 border-left">
                            <p><strong>Detail Leave/Permission</strong></p>
                            <!--[if BLOCK]><![endif]--><?php if(!$pengajuan): ?>
                                <div class="alert alert-info alert-has-icon">
                                    <div class="alert-icon"><i class="far fa-lightbulb"></i></div>
                                    <div class="alert-body">
                                        <div class="alert-title">Info</div>
                                        Please select Leave/Permission First!
                                    </div>
                                </div>
                            <?php else: ?>
                                <table class="table table-striped table-borderless">
                                    <tr>
                                        <th>Type</th>
                                        <td>:</td>
                                        <td class="text-capitalize"><?php echo e($pengajuan->type); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Date</th>
                                        <td>:</td>
                                        <td>
                                            <!--[if BLOCK]><![endif]--><?php if($pengajuan->type === 'cuti'): ?>
                                                <?php echo e($pengajuan->start_date); ?> to <?php echo e($pengajuan->end_date); ?>

                                            <?php else: ?>
                                                <?php echo e($pengajuan->date); ?>

                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Reason</th>
                                        <td>:</td>
                                        <td><?php echo e($pengajuan->reason); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Status</th>
                                        <td>:</td>
                                        <td>
                                            <span class="badge badge-<?php echo e($pengajuan->status === 'pending' ? 'warning' : ($pengajuan->status === 'approved' ? 'success' : 'danger')); ?>">
                                                <?php echo e(ucfirst($pengajuan->status)); ?>

                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Attachment</th>
                                        <td>:</td>
                                        <td>
                                            <!--[if BLOCK]><![endif]--><?php if($pengajuan->attachment): ?>
                                                <a href="<?php echo e(Storage::url($pengajuan->attachment)); ?>" target="_blank">View</a>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                    </tr>
                                </table>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <a href="#" wire:click="home()" class="btn btn-primary">Back</a>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH E:\Repo\PROJECTS\JOKI\presensi-app\resources\views/livewire/reporting-daylog.blade.php ENDPATH**/ ?>