<div class="footer-left">
    Copyright &copy; 2024 SchoolTech Indonesia
  </div>
  <div class="footer-right">
    0.0.1
  </div><?php /**PATH E:\Repo\PROJECTS\JOKI\presensi-app\resources\views/layouts/footer.blade.php ENDPATH**/ ?>