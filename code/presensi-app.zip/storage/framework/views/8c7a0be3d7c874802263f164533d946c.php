<div>
    <div class="card card-statistic-1">
        <div class="card-icon bg-primary">
            <i class="far fa-user"></i>
        </div>
        <div class="card-wrap">
            <div class="card-header">
                <h4>Total Absence</h4>
            </div>
            <div class="card-body">
                <?php echo e($a); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Repo\PROJECTS\JOKI\presensi-app\resources\views/livewire/count-absence.blade.php ENDPATH**/ ?>