<div>
    <!--[if BLOCK]><![endif]--><?php if($isHome): ?>
        <div class="section-header">
            <h1>Admin: Leave & Permission Approvals</h1>
        </div>

        <div class="section-body">
            <h2 class="section-title">Request List</h2>
            <p class="section-lead">Manage all leave & permission requests here.</p>

            <div class="card">
                <div class="card-body">
                    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php elseif(session()->has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>User</th>
                                <th>Type</th>
                                <th>Date</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($idx + $requests->firstItem()); ?></td>
                                    <td><?php echo e($req->user->name); ?></td>
                                    <td class="text-capitalize"><?php echo e($req->type == 'cuti' ? 'Leave' : 'Permission'); ?></td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($req->type === 'cuti'): ?>
                                            <?php echo e($req->start_date); ?> to <?php echo e($req->end_date); ?>

                                        <?php else: ?>
                                            <?php echo e($req->date); ?>

                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td><?php echo e(Str::limit($req->reason, 30)); ?></td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($req->status === 'pending'): ?>
                                            <span class="badge badge-warning">Pending</span>
                                        <?php elseif($req->status === 'approved'): ?>
                                            <span class="badge badge-success">Approved</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Rejected</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td>
                                        <a href="#" wire:click.prevent="show(<?php echo e($req->id); ?>)"
                                           class="btn btn-info btn-sm">
                                            <i class="fas fa-info-circle"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center">No data available.</td>
                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>

                    <?php echo e($requests->links()); ?>

                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($isDetail): ?>
        <div class="section-header">
            <h1>Request Details</h1>
        </div>

        <div class="section-body">
            <h2 class="section-title">Request Information</h2>
            <p class="section-lead">Validate and approve or reject this request.</p>

            <div class="card">
                <div class="card-body">
                    <p><strong>User Data</strong></p>
                    <table class="table table-borderless">
                        <tr>
                            <th>Name</th><td>: <?php echo e($requestItem->user->name); ?></td>
                        </tr>
                        <tr>
                            <th>Email</th><td>: <?php echo e($requestItem->user->email); ?></td>
                        </tr>
                        <tr>
                            <th>Role</th><td>: <?php echo e($requestItem->user->role->name); ?></td>
                        </tr>
                    </table>

                    <hr>

                    <p><strong>Request Details</strong></p>
                    <table class="table table-borderless">
                        <tr>
                            <th>Type</th>
                            <td>: <?php echo e($requestItem->type == 'cuti' ? 'Leave' : 'Permission'); ?></td>
                        </tr>
                        <!--[if BLOCK]><![endif]--><?php if($requestItem->type === 'cuti'): ?>
                            <tr>
                                <th>Start Date</th>
                                <td>: <?php echo e($requestItem->start_date); ?></td>
                            </tr>
                            <tr>
                                <th>End Date</th>
                                <td>: <?php echo e($requestItem->end_date); ?></td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <th>Permission Date</th>
                                <td>: <?php echo e($requestItem->date); ?></td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <tr>
                            <th>Reason</th>
                            <td>: <?php echo e($requestItem->reason); ?></td>
                        </tr>
                        <tr>
                            <th>Attachment</th>
                            <td>:
                                <!--[if BLOCK]><![endif]--><?php if($requestItem->attachment): ?>
                                    <a href="<?php echo e(Storage::url($requestItem->attachment)); ?>" target="_blank">View</a>
                                <?php else: ?>
                                    -
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>:
                                <span class="badge badge-<?php echo e($requestItem->status === 'pending' ? 'warning' : ($requestItem->status === 'approved' ? 'success' : 'danger')); ?>">
                                    <?php echo e(ucfirst($requestItem->status)); ?>

                                </span>
                            </td>
                        </tr>
                    </table>

                    <!--[if BLOCK]><![endif]--><?php if($requestItem->status === 'pending'): ?>
                        <div class="mt-3">
                            <button class="btn btn-success"
                                onclick="confirm('Approve this request?') && window.Livewire.find('<?php echo e($_instance->getId()); ?>').confirmApprove()">
                                Approve
                            </button>
                            <button class="btn btn-danger"
                                onclick="confirm('Reject this request?') && window.Livewire.find('<?php echo e($_instance->getId()); ?>').confirmReject()">
                                Reject
                            </button>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="mt-3">
                        <a href="#" wire:click.prevent="home()" class="btn btn-secondary">Back</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH E:\Repo\PROJECTS\JOKI\presensi-app\resources\views/livewire/pengajuan-admin-menu.blade.php ENDPATH**/ ?>